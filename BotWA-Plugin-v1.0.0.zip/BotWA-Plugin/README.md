# BotWA Plugin

Bot WhatsApp modular berbasis Node.js dan Baileys. Fondasi awal dibuat ringan untuk diuji pada hosting dengan sumber daya terbatas.

## Fitur tahap awal
- Pairing WhatsApp melalui kode yang ditampilkan di terminal.
- Sistem plugin JavaScript lokal.
- Menu, info, owner, waktu, ping, echo.
- Informasi grup dan tagall khusus pemilik.
- Pemeriksaan pemilik pada perintah yang dibatasi.
- Percobaan sambung ulang dengan jeda.
- Tidak menyediakan eval, exec, atau pengunggahan kode plugin melalui WhatsApp.

## Persiapan panel hosting
Atur Environment Variables berikut pada panel:

- `OWNER`: nomor pemilik, contoh format `62812xxxxxxxx`.
- `PHONE_NUMBER`: nomor akun WhatsApp yang akan dipasangkan, format internasional tanpa tanda plus. Hapus atau kosongkan setelah pairing berhasil.
- `SELF_MODE`: `false` agar bot merespons pengguna. Isi `true` jika hanya ingin bot merespons pemilik.
- `PREFIX`: awalan perintah, default `!`.
- `AUTH_DIR`: folder sesi, default `baileys_auth_info`.

Jangan menaruh nomor rahasia, kode pairing, atau isi folder sesi ke repositori publik. Folder sesi adalah kredensial akun WhatsApp.

## Menjalankan
```bash
npm install --omit=dev
npm start
```

Jika panel menyediakan Startup Command, gunakan `npm start`.

Saat pairing pertama, lihat kode pada Console. Masukkan sendiri melalui WhatsApp > Perangkat tertaut > Tautkan perangkat. Jangan kirim kode pairing ke siapa pun. Setelah berhasil, kosongkan variabel `PHONE_NUMBER` dan restart server. Pastikan direktori sesi tersimpan permanen oleh hosting.

## Menambah plugin
Buat file JavaScript baru di `src/plugins/` atau satu tingkat subfolder di dalamnya. Bentuk plugin:

```js
export default function (register) {
  register({
    name: 'halo',
    alias: ['hi'],
    category: 'Umum',
    description: 'Contoh perintah.',
    async run({ reply, text }) {
      return reply(`Halo! ${text}`);
    }
  });
}
```

Plugin hanya dimuat dari file lokal di repositori/server. Tidak ada fitur memasukkan kode JavaScript melalui chat WhatsApp.

## Catatan kompatibilitas dan keamanan
- Baileys merupakan library tidak resmi yang menggunakan protokol WhatsApp Web. Penggunaan dapat mengalami perubahan kompatibilitas atau pembatasan dari WhatsApp.
- Jangan aktifkan fitur eksekusi kode jarak jauh.
- Batas RAM/disk hosting harus diuji saat instalasi. Paket ini belum dinyatakan lolos uji pada semua paket hosting 256 MB.
- Jangan mengunggah `.env`, `node_modules`, atau folder `baileys_auth_info` ke GitHub.
