import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const registry = new Map();
const PREFIX = process.env.PREFIX || '!';

export function register(command) {
  if (!command || !command.name || typeof command.run !== 'function') {
    throw new Error('Plugin harus memiliki name dan fungsi run.');
  }
  const names = [command.name, ...(command.alias || [])].map(v => String(v).toLowerCase());
  for (const name of names) {
    if (registry.has(name)) throw new Error(`Nama perintah duplikat: ${name}`);
  }
  for (const name of names) registry.set(name, command);
}

export async function loadPlugins() {
  registry.clear();
  const dir = path.resolve('src/plugins');
  await fs.mkdir(dir, { recursive: true });
  const categories = await fs.readdir(dir, { withFileTypes: true });
  const files = [];
  for (const item of categories) {
    if (item.isFile() && item.name.endsWith('.js')) files.push(path.join(dir, item.name));
    if (item.isDirectory()) {
      const sub = path.join(dir, item.name);
      for (const f of await fs.readdir(sub, { withFileTypes: true })) {
        if (f.isFile() && f.name.endsWith('.js')) files.push(path.join(sub, f.name));
      }
    }
  }
  for (const file of files.sort()) {
    const mod = await import(`${pathToFileURL(file).href}?v=${Date.now()}-${Math.random()}`);
    if (typeof mod.default === 'function') await mod.default(register);
  }
  console.log(`[BOTWA] ${registry.size} alias/perintah berhasil dimuat.`);
}

function getText(message) {
  const m = message.message || {};
  return m.conversation
    || m.extendedTextMessage?.text
    || m.imageMessage?.caption
    || m.videoMessage?.caption
    || m.documentMessage?.caption
    || m.buttonsResponseMessage?.selectedButtonId
    || m.listResponseMessage?.singleSelectReply?.selectedRowId
    || '';
}

export async function dispatchMessage(sock, message, config) {
  if (!message?.message || message.key?.remoteJid === 'status@broadcast') return;
  const jid = message.key.remoteJid;
  const senderJid = message.key.participant || jid;
  const sender = senderJid.split('@')[0].split(':')[0];
  const fromMe = Boolean(message.key.fromMe);
  const body = getText(message).trim();
  if (!body.startsWith(PREFIX)) return;
  if (config.SELF_MODE && !fromMe && sender !== config.OWNER) return;

  const parts = body.slice(PREFIX.length).trim().split(/\s+/);
  const name = (parts.shift() || '').toLowerCase();
  const command = registry.get(name);
  if (!command) return;
  const isGroup = jid.endsWith('@g.us');
  const reply = text => sock.sendMessage(jid, { text: String(text) }, { quoted: message });

  if (command.owner && sender !== config.OWNER) return reply('Perintah ini khusus pemilik bot.');
  if (command.group && !isGroup) return reply('Perintah ini hanya dapat digunakan di grup.');
  if (command.private && isGroup) return reply('Silakan gunakan perintah ini melalui chat pribadi.');

  await command.run({
    sock, message, jid, sender, senderJid, fromMe, isGroup,
    args: parts, text: parts.join(' '), body, reply,
    pushName: message.pushName || 'Pengguna', owner: config.OWNER
  });
}
