export default function (register) {
  register({
    name: 'ping', alias: ['tes'], category: 'Tools',
    description: 'Menguji apakah bot merespons.',
    async run({ reply }) { return reply('Pong! Bot aktif dan merespons.'); }
  });
  register({
    name: 'echo', alias: ['say'], category: 'Tools',
    description: 'Mengulang teks yang dikirim.',
    async run({ reply, text }) {
      if (!text) return reply('Contoh: !echo Halo semuanya');
      return reply(text.slice(0, 1500));
    }
  });
}
