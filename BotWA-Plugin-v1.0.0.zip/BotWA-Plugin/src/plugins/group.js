export default function (register) {
  register({
    name: 'groupinfo', alias: ['infogrup'], category: 'Grup', group: true,
    description: 'Menampilkan informasi grup.',
    async run({ sock, jid, reply }) {
      const meta = await sock.groupMetadata(jid);
      return reply(`*INFORMASI GRUP*\nNama: ${meta.subject || '-'}\nJumlah anggota: ${meta.participants?.length || 0}\nID: ${jid}`);
    }
  });
  register({
    name: 'tagall', alias: ['semua'], category: 'Grup', group: true, owner: true,
    description: 'Menandai seluruh anggota grup. Khusus pemilik bot.',
    async run({ sock, jid, reply, text }) {
      const meta = await sock.groupMetadata(jid);
      const members = (meta.participants || []).map(p => p.id).filter(Boolean);
      if (!members.length) return reply('Anggota grup tidak ditemukan.');
      const mentions = members.map(id => `@${id.split('@')[0]}`);
      return sock.sendMessage(jid, { text: `${text || 'Perhatian seluruh anggota'}\n\n${mentions.join(' ')}`, mentions: members });
    }
  });
}
