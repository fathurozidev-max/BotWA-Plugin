export default function (register) {
  register({
    name: 'menu', alias: ['help', 'daftar'], category: 'Informasi',
    description: 'Menampilkan daftar perintah yang tersedia.',
    async run({ reply }) {
      return reply(
        '*BOTWA PLUGIN*\n\n' +
        '*Informasi*\n' +
        '!menu - Daftar perintah\n' +
        '!ping - Cek respons bot\n' +
        '!info - Informasi bot\n' +
        '!owner - Kontak pemilik bot\n' +
        '!waktu - Waktu server\n\n' +
        'Plugin tambahan akan ditambahkan bertahap. Gunakan tanda ! di awal perintah.'
      );
    }
  });
  register({
    name: 'info', alias: ['about'], category: 'Informasi',
    description: 'Informasi singkat bot.',
    async run({ reply }) {
      return reply('*BOTWA PLUGIN*\nBot WhatsApp modular berbasis Node.js dan Baileys.\nVersi: 1.0.0\nSistem plugin lokal aktif.');
    }
  });
  register({
    name: 'owner', alias: ['pemilik'], category: 'Informasi',
    description: 'Menampilkan nomor pemilik bot.',
    async run({ reply, owner }) {
      return reply(owner ? `Pemilik bot: wa.me/${owner}` : 'Nomor pemilik belum diatur.');
    }
  });
  register({
    name: 'waktu', alias: ['time'], category: 'Tools',
    description: 'Menampilkan waktu server Indonesia.',
    async run({ reply }) {
      return reply(new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', dateStyle: 'full', timeStyle: 'long' }));
    }
  });
}
