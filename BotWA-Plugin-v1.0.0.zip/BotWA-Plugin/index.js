import makeWASocket, {
  DisconnectReason,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  makeCacheableSignalKeyStore,
  Browsers
} from 'baileys';
import pino from 'pino';
import { loadPlugins, dispatchMessage } from './src/commands.js';

const logger = pino({ level: 'silent' });
const OWNER = String(process.env.OWNER || '').replace(/\D/g, '');
const PHONE_NUMBER = String(process.env.PHONE_NUMBER || '').replace(/\D/g, '');
const AUTH_DIR = process.env.AUTH_DIR || 'baileys_auth_info';
const SELF_MODE = String(process.env.SELF_MODE || 'false').toLowerCase() === 'true';

let reconnectTimer;
let isStarting = false;
let stoppedByLogout = false;

function log(message) {
  console.log(`[BOTWA] ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} ${message}`);
}

async function startBot() {
  if (isStarting || stoppedByLogout) return;
  isStarting = true;
  try {
    await loadPlugins();
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    const { version } = await fetchLatestBaileysVersion();
    const sock = makeWASocket({
      version,
      logger,
      printQRInTerminal: false,
      browser: Browsers.ubuntu('BotWA Plugin'),
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, logger)
      },
      markOnlineOnConnect: false,
      syncFullHistory: false,
      generateHighQualityLinkPreview: false,
      getMessage: async () => ({ conversation: '' })
    });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect } = update;
      if (connection === 'connecting') log('Menghubungkan ke WhatsApp...');
      if (connection === 'open') log('Berhasil terhubung ke WhatsApp.');
      if (connection === 'close') {
        const code = lastDisconnect?.error?.output?.statusCode;
        if (code === DisconnectReason.loggedOut) {
          stoppedByLogout = true;
          log('Sesi logout. Hapus sesi hanya jika ingin memasangkan ulang.');
          return;
        }
        log(`Koneksi terputus (kode ${code ?? 'tidak diketahui'}). Mencoba kembali dalam 8 detik.`);
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(() => {
          isStarting = false;
          startBot();
        }, 8000);
      }
    });

    if (!state.creds.registered) {
      if (!PHONE_NUMBER) {
        log('PHONE_NUMBER belum diatur. Isi variabel ini di Environment panel, lalu mulai ulang server.');
      } else {
        try {
          await new Promise(resolve => setTimeout(resolve, 1500));
          const code = await sock.requestPairingCode(PHONE_NUMBER);
          log(`KODE PAIRING: ${code}`);
          log('Masukkan kode tersebut sendiri di WhatsApp > Perangkat tertaut > Tautkan perangkat. Jangan bagikan kode ini kepada siapa pun.');
        } catch (error) {
          log(`Gagal meminta pairing code: ${error?.message || error}`);
        }
      }
    }

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      if (type !== 'notify') return;
      for (const message of messages) {
        try {
          await dispatchMessage(sock, message, { OWNER, SELF_MODE });
        } catch (error) {
          log(`Kesalahan memproses pesan: ${error?.message || error}`);
        }
      }
    });
  } catch (error) {
    log(`Gagal memulai bot: ${error?.stack || error}`);
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(() => {
      isStarting = false;
      startBot();
    }, 12000);
  }
}

process.on('unhandledRejection', error => log(`Unhandled rejection: ${error?.message || error}`));
process.on('uncaughtException', error => log(`Uncaught exception: ${error?.message || error}`));
process.on('SIGTERM', () => { clearTimeout(reconnectTimer); process.exit(0); });
process.on('SIGINT', () => { clearTimeout(reconnectTimer); process.exit(0); });

if (!OWNER) log('PERINGATAN: OWNER belum diatur. Perintah khusus pemilik tidak akan bisa digunakan.');
startBot();
